import re, math, json, openpyxl, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm, spearmanr
OUT='/mnt/user-data/outputs/Centrus_Research/figures/'
NAVY='#1F3864'; ORG='#E07B24'; GRY='#8C8C8C'; RED='#C0392B'; GRN='#2E7D32'
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
U='/root/.claude/uploads/29f22cc5-5212-5935-8f2a-2922cbce618b/'
res={}
# ---------- A. Earnings event study
ws=openpyxl.load_workbook(U+'96bf79dd-grid_fzvaxlk0.xlsx',data_only=True).active
rows=[]
for r in ws.iter_rows(min_row=3,values_only=True):
    per,rep,comp,est,surp,px=r[1],r[4],r[5],r[6],r[7],r[10]
    if px is None or est is None or comp is None: continue
    pxv=float(px.strip('%'))/100
    rows.append((per,comp,est,pxv))
rows=rows[::-1]  # chronological
per=[r[0] for r in rows]; comp=np.array([r[1] for r in rows]); est=np.array([r[2] for r in rows]); px=np.array([r[3] for r in rows])
beat=comp>est
res['n_q']=len(rows); res['first']=per[0]; res['last']=per[-1]
res['beat_rate']=beat.mean(); res['mean_abs']=np.abs(px).mean()
res['up_after_beat']=(px[beat]>0).mean(); res['avg_after_beat']=px[beat].mean()
res['avg_after_miss']=px[~beat].mean() if (~beat).sum() else None; res['n_miss']=int((~beat).sum())
sp=spearmanr(comp-est,px); res['spearman']=sp.correlation; res['sp_p']=sp.pvalue
last4=px[-4:]; res['last4']=list(last4); res['last4_avg']=last4.mean()
prior=px[-12:-4]; res['prior8_avg']=prior.mean()
# rolling: since Q3'25
fig,ax=plt.subplots(figsize=(7.2,2.4))
cols=[GRN if b else RED for b in beat]
ax.bar(range(len(px)),px*100,color=cols)
ax.set_xticks(range(len(px))); ax.set_xticklabels(per,rotation=60,fontsize=7)
ax.axhline(0,color='k',lw=0.6); ax.set_ylabel('Results-day move (%)')
ax.axvspan(len(px)-4.5,len(px)-0.5,color=GRY,alpha=0.15)
ax.text(len(px)-2.5,ax.get_ylim()[0]*0.75,'last 4 reports:\navg %+.0f%%'%(last4.mean()*100),ha='center',fontsize=8)
ax.set_title('Results-day share-price move (green = EPS beat, red = miss)',fontsize=9,color=NAVY,loc='left')
fig.text(0.01,0.01,'Source: Bloomberg ERN (Q1 2021 - Q2 2026).',fontsize=6,color=GRY)
plt.tight_layout(); plt.savefig(OUT+'r1_event.png',dpi=200); plt.close()
# ---------- B. Options
ws=openpyxl.load_workbook(U+'55a7d54c-grid_rz0gglzw.xlsx',data_only=True).active
S=103.29; r=0.0431
chains={}; cur=None
for row in ws.iter_rows(values_only=True):
    if isinstance(row[0],str) and 'CSize' in row[0]:
        cur=row[0].split(' ')[0]; days=int(re.search(r'\((\d+)d\)',row[0]).group(1)); chains[cur]={'T':days/365,'rows':[]}; continue
    if cur and isinstance(row[0],(int,float)):
        K,cb,ca,civ,pb,pa,piv=row[0],row[2],row[3],row[5],row[9],row[10],row[12]
        chains[cur]['rows'].append((K,cb,ca,civ,pb,pa,piv))
out={}
for name,ch in chains.items():
    T=ch['T']; rr=ch['rows']
    def mid(b,a): return (b+a)/2 if (b and a and a>0 and b>0) else None
    atm=min(rr,key=lambda x:abs(x[0]-S))
    k100=[x for x in rr if x[0]==100][0]
    straddle=mid(k100[1],k100[2])+mid(k100[4],k100[5])
    # implied borrow from put-call parity for strikes 85-120 with two-sided quotes
    bs=[]
    for K,cb,ca,civ,pb,pa,piv in rr:
        if 85<=K<=120:
            c=mid(cb,ca); p=mid(pb,pa)
            if c and p:
                # C - P = S*exp(-q T) - K exp(-rT)  => q
                val=(c-p+K*math.exp(-r*T))/S
                if val>0: bs.append(-math.log(val)/T)
    out[name]={'T':T,'straddle':straddle,'move':straddle/S,'borrow_med':float(np.median(bs)),'borrow_n':len(bs),
               'iv_put90':[x[6] for x in rr if x[0]==90][0],'iv_call110':[x[3] for x in rr if x[0]==110][0],
               'iv_put100':k100[6],'iv_call100':k100[3]}
    out[name]['rows']=rr
res['opt']={k:{kk:vv for kk,vv in v.items() if kk!='rows'} for k,v in out.items()}
dec=out['18-Dec-26']; T=dec['T']
p100=[(x[4]+x[5])/2 for x in dec['rows'] if x[0]==100][0]; p80=[(x[4]+x[5])/2 for x in dec['rows'] if x[0]==80][0]
res['ps_cost']=p100-p80; res['ps_max']=20; res['ps_be']=100-(p100-p80)
sig=0.88; d2=(math.log(S/80)+(r-0.5*sig**2)*T)/(sig*math.sqrt(T)); res['rn_prob_below80_dec']=norm.cdf(-d2)
# smile chart
fig,ax=plt.subplots(figsize=(3.5,2.4))
for name,c in [('20-Nov-26',NAVY),('18-Dec-26',ORG)]:
    rr=out[name]['rows']
    xs=[];ys=[]
    for K,cb,ca,civ,pb,pa,piv in rr:
        if 70<=K<=150:
            iv=piv if K<S else civ
            if iv and iv>0: xs.append(K); ys.append(iv)
    ax.plot(xs,ys,'o-',ms=3,color=c,label=name+' (%dd)'%round(out[name]['T']*365))
ax.axvline(S,color=GRY,ls='--',lw=0.8); ax.text(S+1,ax.get_ylim()[0]+2,'spot',fontsize=7,color=GRY)
ax.set_xlabel('Strike ($)'); ax.set_ylabel('Implied vol (%)'); ax.legend(fontsize=7,frameon=False)
ax.set_title('OTM implied volatility by strike',fontsize=9,color=NAVY,loc='left')
fig.text(0.01,0.01,'Source: Bloomberg OMON, 1-Nov-2026.',fontsize=6,color=GRY)
plt.tight_layout(); plt.savefig(OUT+'r2_smile.png',dpi=200); plt.close()
# ---------- C. Text analytics
def load(p):
    t=open(p,errors='ignore').read().lower(); return t,len(re.findall(r'[a-z]+',t))
k,kw=load('/home/claude/k24.txt'); q,qw=load('/home/claude/q2.txt')
terms={'Russia / Russian':r'\brussia\w*','TENEX':r'\btenex\b','waiver':r'\bwaiver','Import Ban Act':r'import ban','contingent':r'\bcontingen\w*',
'"no assurance"':r'no assurance','sanction':r'\bsanction\w*','HALEU':r'\bhaleu\b','Piketon':r'\bpiketon\b','dilution / dilutive':r'\bdilution\b|\bdilutive\b','financing':r'\bfinanc\w*'}
tx=[]
for lab,pat in terms.items():
    a=len(re.findall(pat,k)); b=len(re.findall(pat,q))
    tx.append((lab,a,a/kw*1e4,b,b/qw*1e4))
res['tx']=tx; res['kw']=kw; res['qw']=qw
fig,ax=plt.subplots(figsize=(3.6,2.6))
labs=[t[0] for t in tx]; y=np.arange(len(labs))
ax.barh(y+0.2,[t[2] for t in tx],0.4,color=GRY,label='FY2024 10-K')
ax.barh(y-0.2,[t[4] for t in tx],0.4,color=NAVY,label="Q2'26 10-Q")
ax.set_yticks(y); ax.set_yticklabels(labs,fontsize=7); ax.invert_yaxis(); ax.set_xlabel('Mentions per 10,000 words')
ax.legend(fontsize=7,frameon=False); ax.set_title('Filing language: keyword intensity',fontsize=9,color=NAVY,loc='left')
fig.text(0.01,0.01,'Source: Centrus FY2024 10-K, Q2 2026 10-Q; analyst text analysis.',fontsize=6,color=GRY)
plt.tight_layout(); plt.savefig(OUT+'r3_text.png',dpi=200); plt.close()
# ---------- D. Backlog waterfall
fig,ax=plt.subplots(figsize=(3.6,2.5))
steps=[('Headline\nbacklog',4.5,0,NAVY),('Contingent on\nPiketon',-3.0,4.5,RED),('TS / HALEU op.\n(unfunded FY27)',-0.8,1.5,RED),('Firm\n(LEU)',0.7,0,GRN)]
for i,(l,v,b,c) in enumerate(steps):
    if v<0: ax.bar(i,-v,bottom=b+v,color=c)
    else: ax.bar(i,v,bottom=b,color=c)
    ax.text(i,(b+v if v<0 else v)+0.08 if v>0 else b+0.08,'$%.1fB'%abs(v),ha='center',fontsize=8)
ax.set_xticks(range(4)); ax.set_xticklabels([s[0] for s in steps],fontsize=7); ax.set_ylabel('$B')
ax.set_title('Backlog quality, 30-Jun-2026',fontsize=9,color=NAVY,loc='left')
fig.text(0.01,0.01,'Source: Q2 2026 10-Q (MD&A backlog; Note 2 RPO $0.8B incl. $40M TS).',fontsize=6,color=GRY)
plt.tight_layout(); plt.savefig(OUT+'r4_backlog.png',dpi=200); plt.close()
# ---------- E. Sentences from 10-Q
sents=re.split(r'(?<=[.])\s+',re.sub(r'\s+',' ',open('/home/claude/q2.txt').read()))
pick=[s for s in sents if ('contingent' in s.lower() and 'backlog' in s.lower()) or 'fiscal year 2027' in s.lower()]
res['sentences']=pick[:4]
json.dump(res,open('/home/claude/research.json','w'),indent=1,default=float)
print(json.dumps({k:v for k,v in res.items() if k not in ('sentences',)},indent=1,default=float))
